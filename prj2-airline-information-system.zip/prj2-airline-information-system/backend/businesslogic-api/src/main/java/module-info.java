/**
 * Module businesslogic_api.
 */
module businesslogic_api_module {
    
    requires datarecords_module;
    
    exports io.github.fontysvenlo.ais.businesslogic.api;
}
