/**
 * Module persistence_api_module.
 */
module persistence_api_module { 
    
    requires datarecords_module;
    
    exports io.github.fontysvenlo.ais.persistence.api;
}
