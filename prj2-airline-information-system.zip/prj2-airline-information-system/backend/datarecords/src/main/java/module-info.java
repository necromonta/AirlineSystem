/**
 * Module datarecords_module.
 */
module datarecords_module {       
    exports io.github.fontysvenlo.ais.datarecords;
}
